/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
extern char *STD_STANDARD;
extern char *IEEE_P_3972351953;
extern char *IEEE_P_3499444699;
static const char *ng3 = "C:/Users/Shahriar Shahramian/Desktop/32x32LEDMatrix/32x32LEDMatrix/fpga/gamma_table.vhd";
extern char *IEEE_P_2592010699;
extern char *IEEE_P_3620187407;

unsigned char ieee_p_2592010699_sub_1744673427_503743352(char *, char *, unsigned int , unsigned int );
char *ieee_p_3499444699_sub_2213602152_3536714472(char *, char *, int , int );
int ieee_p_3620187407_sub_514432868_3965413181(char *, char *, char *);
double ieee_p_3972351953_sub_2618671228_2984157535(char *, double , double );


char *work_a_0280078389_1516540902_sub_2634708603_2134189630(char *t1, int t2, double t3)
{
    char t4[248];
    char t5[16];
    char t6[32];
    char t15[2048];
    char t24[8];
    char t47[16];
    char *t0;
    char *t7;
    char *t8;
    int t9;
    unsigned int t10;
    char *t11;
    int t12;
    char *t13;
    char *t14;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    int t29;
    int t30;
    int t31;
    int t32;
    int t33;
    int t34;
    int t35;
    int t36;
    double t37;
    double t38;
    double t39;
    int t40;
    unsigned char t41;
    unsigned char t42;
    double t43;
    double t44;
    char *t45;
    char *t46;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;

LAB0:    t7 = (t6 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 255;
    t8 = (t7 + 4U);
    *((int *)t8) = 0;
    t8 = (t7 + 8U);
    *((int *)t8) = -1;
    t9 = (0 - 255);
    t10 = (t9 * -1);
    t10 = (t10 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t10;
    t8 = (t6 + 16U);
    t11 = (t8 + 0U);
    *((int *)t11) = 7;
    t11 = (t8 + 4U);
    *((int *)t11) = 0;
    t11 = (t8 + 8U);
    *((int *)t11) = -1;
    t12 = (0 - 7);
    t10 = (t12 * -1);
    t10 = (t10 + 1);
    t11 = (t8 + 12U);
    *((unsigned int *)t11) = t10;
    t11 = (t4 + 4U);
    t13 = (t1 + 3768);
    t14 = (t11 + 88U);
    *((char **)t14) = t13;
    t16 = (t11 + 56U);
    *((char **)t16) = t15;
    xsi_type_set_default_value(t13, t15, 0);
    t17 = (t11 + 64U);
    t18 = (t13 + 80U);
    t19 = *((char **)t18);
    *((char **)t17) = t19;
    t20 = (t11 + 80U);
    *((unsigned int *)t20) = 2048U;
    t21 = (t4 + 124U);
    t22 = ((STD_STANDARD) + 384);
    t23 = (t21 + 88U);
    *((char **)t23) = t22;
    t25 = (t21 + 56U);
    *((char **)t25) = t24;
    xsi_type_set_default_value(t22, t24, 0);
    t26 = (t21 + 80U);
    *((unsigned int *)t26) = 4U;
    t27 = (t5 + 4U);
    *((int *)t27) = t2;
    t28 = (t5 + 8U);
    *((double *)t28) = t3;
    t29 = xsi_vhdl_pow(2, t2);
    t30 = (t29 - 1);
    t31 = 0;
    t32 = t30;

LAB2:    if (t31 <= t32)
        goto LAB3;

LAB5:    t7 = (t11 + 56U);
    t8 = *((char **)t7);
    t41 = (2048U != 2048U);
    if (t41 == 1)
        goto LAB12;

LAB13:    t0 = xsi_get_transient_memory(2048U);
    memcpy(t0, t8, 2048U);

LAB1:    return t0;
LAB3:    t33 = xsi_vhdl_pow(2, t2);
    t34 = (t33 - 1);
    t35 = xsi_vhdl_pow(2, t2);
    t36 = (t35 - 1);
    t37 = ((((double)(t31))) / (((double)(t36))));
    t38 = ieee_p_3972351953_sub_2618671228_2984157535(IEEE_P_3972351953, t37, t3);
    t39 = ((((double)(t34))) * t38);
    t41 = (t39 >= 0);
    if (t41 == 1)
        goto LAB6;

LAB7:    t44 = (t39 - 0.50000000000000000);
    t40 = ((int)(t44));

LAB8:    t45 = (t21 + 56U);
    t46 = *((char **)t45);
    t45 = (t46 + 0);
    *((int *)t45) = t40;
    t7 = (t21 + 56U);
    t8 = *((char **)t7);
    t9 = *((int *)t8);
    t7 = ieee_p_3499444699_sub_2213602152_3536714472(IEEE_P_3499444699, t47, t9, t2);
    t13 = (t11 + 56U);
    t14 = *((char **)t13);
    t12 = (t31 - 255);
    t10 = (t12 * -1);
    xsi_vhdl_check_range_of_index(255, 0, -1, t31);
    t29 = (8 - 1);
    t30 = (0 - t29);
    t48 = (t30 * -1);
    t48 = (t48 + 1);
    t48 = (t48 * 1U);
    t49 = (t48 * t10);
    t50 = (0 + t49);
    t13 = (t14 + t50);
    t16 = (t47 + 12U);
    t51 = *((unsigned int *)t16);
    t51 = (t51 * 1U);
    memcpy(t13, t7, t51);

LAB4:    if (t31 == t32)
        goto LAB5;

LAB11:    t9 = (t31 + 1);
    t31 = t9;
    goto LAB2;

LAB6:    t42 = (t39 >= 2147483647);
    if (t42 == 1)
        goto LAB9;

LAB10:    t43 = (t39 + 0.50000000000000000);
    t40 = ((int)(t43));
    goto LAB8;

LAB9:    t40 = 2147483647;
    goto LAB8;

LAB12:    xsi_size_not_matching(2048U, 2048U, 0);
    goto LAB13;

LAB14:;
}

static void work_a_0280078389_1516540902_p_0(char *t0)
{
    char *t1;
    unsigned char t2;
    char *t3;
    char *t4;
    char *t5;
    int t6;
    int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    xsi_set_current_line(40, ng3);
    t1 = (t0 + 992U);
    t2 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 3192);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(41, ng3);
    t3 = (t0 + 1888U);
    t4 = *((char **)t3);
    t3 = (t0 + 1192U);
    t5 = *((char **)t3);
    t3 = (t0 + 5796U);
    t6 = ieee_p_3620187407_sub_514432868_3965413181(IEEE_P_3620187407, t5, t3);
    t7 = (t6 - 255);
    t8 = (t7 * -1);
    xsi_vhdl_check_range_of_index(255, 0, -1, t6);
    t9 = (8U * t8);
    t10 = (0 + t9);
    t11 = (t4 + t10);
    t12 = (t0 + 3272);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    memcpy(t16, t11, 8U);
    xsi_driver_first_trans_fast_port(t12);
    goto LAB3;

}


extern void work_a_0280078389_1516540902_init()
{
	static char *pe[] = {(void *)work_a_0280078389_1516540902_p_0};
	static char *se[] = {(void *)work_a_0280078389_1516540902_sub_2634708603_2134189630};
	xsi_register_didat("work_a_0280078389_1516540902", "isim/fpga_top_isim_beh.exe.sim/work/a_0280078389_1516540902.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
