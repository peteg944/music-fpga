/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
extern char *STD_STANDARD;
extern char *IEEE_P_3499444699;
static const char *ng2 = "C:/Users/Shahriar/Desktop/32x32LEDMatrix/fpga/bram.vhd";
extern char *IEEE_P_2592010699;
extern char *IEEE_P_3620187407;

unsigned char ieee_p_2592010699_sub_1744673427_503743352(char *, char *, unsigned int , unsigned int );
char *ieee_p_3499444699_sub_2213602152_3536714472(char *, char *, int , int );
int ieee_p_3620187407_sub_514432868_3965413181(char *, char *, char *);


char *work_a_3000712498_0000452272_sub_3649022489_4251431050(char *t1, int t2, int t3)
{
    char t4[248];
    char t5[16];
    char t6[32];
    char t15[8192];
    char t24[8];
    char t33[16];
    char *t0;
    char *t7;
    char *t8;
    int t9;
    unsigned int t10;
    char *t11;
    int t12;
    char *t13;
    char *t14;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    int t29;
    int t30;
    int t31;
    int t32;
    int t34;
    int t35;
    int t36;
    int t37;
    int t38;
    int t39;
    int t40;
    int t41;
    char *t42;
    char *t43;
    char *t44;
    int t45;
    int t46;
    int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    char *t51;
    unsigned int t52;
    unsigned char t53;

LAB0:    t7 = (t6 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 1023;
    t8 = (t7 + 4U);
    *((int *)t8) = 0;
    t8 = (t7 + 8U);
    *((int *)t8) = -1;
    t9 = (0 - 1023);
    t10 = (t9 * -1);
    t10 = (t10 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t10;
    t8 = (t6 + 16U);
    t11 = (t8 + 0U);
    *((int *)t11) = 7;
    t11 = (t8 + 4U);
    *((int *)t11) = 0;
    t11 = (t8 + 8U);
    *((int *)t11) = -1;
    t12 = (0 - 7);
    t10 = (t12 * -1);
    t10 = (t10 + 1);
    t11 = (t8 + 12U);
    *((unsigned int *)t11) = t10;
    t11 = (t4 + 4U);
    t13 = (t1 + 4776);
    t14 = (t11 + 88U);
    *((char **)t14) = t13;
    t16 = (t11 + 56U);
    *((char **)t16) = t15;
    xsi_type_set_default_value(t13, t15, 0);
    t17 = (t11 + 64U);
    t18 = (t13 + 80U);
    t19 = *((char **)t18);
    *((char **)t17) = t19;
    t20 = (t11 + 80U);
    *((unsigned int *)t20) = 8192U;
    t21 = (t4 + 124U);
    t22 = ((STD_STANDARD) + 384);
    t23 = (t21 + 88U);
    *((char **)t23) = t22;
    t25 = (t21 + 56U);
    *((char **)t25) = t24;
    xsi_type_set_default_value(t22, t24, 0);
    t26 = (t21 + 80U);
    *((unsigned int *)t26) = 4U;
    t27 = (t5 + 4U);
    *((int *)t27) = t2;
    t28 = (t5 + 8U);
    *((int *)t28) = t3;
    t29 = xsi_vhdl_pow(2, t2);
    t30 = (t29 - 1);
    t31 = 0;
    t32 = t30;

LAB2:    if (t31 <= t32)
        goto LAB3;

LAB5:    t7 = (t11 + 56U);
    t8 = *((char **)t7);
    t53 = (8192U != 8192U);
    if (t53 == 1)
        goto LAB7;

LAB8:    t0 = xsi_get_transient_memory(8192U);
    memcpy(t0, t8, 8192U);

LAB1:    return t0;
LAB3:    t34 = (t3 + 1);
    t35 = xsi_vhdl_pow(2, t34);
    t36 = (t31 * t35);
    t37 = (t2 - 1);
    t38 = xsi_vhdl_pow(2, t37);
    t39 = (t36 / t38);
    t40 = xsi_vhdl_pow(2, t2);
    t41 = xsi_vhdl_mod(t39, t40);
    t42 = ieee_p_3499444699_sub_2213602152_3536714472(IEEE_P_3499444699, t33, t41, t3);
    t43 = (t11 + 56U);
    t44 = *((char **)t43);
    t45 = (t31 - 1023);
    t10 = (t45 * -1);
    xsi_vhdl_check_range_of_index(1023, 0, -1, t31);
    t46 = (8 - 1);
    t47 = (0 - t46);
    t48 = (t47 * -1);
    t48 = (t48 + 1);
    t48 = (t48 * 1U);
    t49 = (t48 * t10);
    t50 = (0 + t49);
    t43 = (t44 + t50);
    t51 = (t33 + 12U);
    t52 = *((unsigned int *)t51);
    t52 = (t52 * 1U);
    memcpy(t43, t42, t52);

LAB4:    if (t31 == t32)
        goto LAB5;

LAB6:    t9 = (t31 + 1);
    t31 = t9;
    goto LAB2;

LAB7:    xsi_size_not_matching(8192U, 8192U, 0);
    goto LAB8;

LAB9:;
}

static void work_a_3000712498_0000452272_p_0(char *t0)
{
    char *t1;
    unsigned char t2;
    char *t3;
    char *t4;
    unsigned char t5;
    unsigned char t6;
    char *t7;
    char *t8;
    int t9;
    int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;

LAB0:    xsi_set_current_line(61, ng2);
    t1 = (t0 + 1152U);
    t2 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 4120);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(62, ng2);
    t3 = (t0 + 1352U);
    t4 = *((char **)t3);
    t5 = *((unsigned char *)t4);
    t6 = (t5 == (unsigned char)3);
    if (t6 != 0)
        goto LAB5;

LAB7:
LAB6:    goto LAB3;

LAB5:    xsi_set_current_line(63, ng2);
    t3 = (t0 + 1832U);
    t7 = *((char **)t3);
    t3 = (t0 + 1512U);
    t8 = *((char **)t3);
    t3 = (t0 + 6772U);
    t9 = ieee_p_3620187407_sub_514432868_3965413181(IEEE_P_3620187407, t8, t3);
    t10 = (t9 - 1023);
    t11 = (t10 * -1);
    t12 = (8U * t11);
    t13 = (0U + t12);
    t14 = (t0 + 4216);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    memcpy(t18, t7, 8U);
    xsi_driver_first_trans_delta(t14, t13, 8U, 0LL);
    goto LAB6;

}

static void work_a_3000712498_0000452272_p_1(char *t0)
{
    char *t1;
    unsigned char t2;
    char *t3;
    char *t4;
    char *t5;
    int t6;
    int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    xsi_set_current_line(70, ng2);
    t1 = (t0 + 992U);
    t2 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 4136);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(71, ng2);
    t3 = (t0 + 2152U);
    t4 = *((char **)t3);
    t3 = (t0 + 1672U);
    t5 = *((char **)t3);
    t3 = (t0 + 6788U);
    t6 = ieee_p_3620187407_sub_514432868_3965413181(IEEE_P_3620187407, t5, t3);
    t7 = (t6 - 1023);
    t8 = (t7 * -1);
    xsi_vhdl_check_range_of_index(1023, 0, -1, t6);
    t9 = (8U * t8);
    t10 = (0 + t9);
    t11 = (t4 + t10);
    t12 = (t0 + 4280);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    memcpy(t16, t11, 8U);
    xsi_driver_first_trans_fast_port(t12);
    goto LAB3;

}


extern void work_a_3000712498_0000452272_init()
{
	static char *pe[] = {(void *)work_a_3000712498_0000452272_p_0,(void *)work_a_3000712498_0000452272_p_1};
	static char *se[] = {(void *)work_a_3000712498_0000452272_sub_3649022489_4251431050};
	xsi_register_didat("work_a_3000712498_0000452272", "isim/fpga_tb_isim_beh.exe.sim/work/a_3000712498_0000452272.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
